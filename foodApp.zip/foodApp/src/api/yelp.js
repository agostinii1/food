import axios from "axios";

export default axios.create({
    baseURL: "https://api.yelp.com/v3/businesses",
    headers:{
        Authorization: "Bearer lzo10jKyCO52AcuwvuxoYuOq8spVLKR4y7S1RgThvHRIilkCVtPp9LWNY6NTf1ty1rwCGhpJHVmIy2JbodE4Pvmd7KdYDqRVtitGbEWIEvdWdHUCR7sKxIgwUbpvXXYx"
    }
});

